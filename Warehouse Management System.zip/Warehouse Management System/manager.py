from log import *
from items import *
class Manager():

    managerName = 'SaveStrongEast'

    log = Log()


    def showStockInfo(self,shelves): #展示仓库现有所有物品的信息[功能]
        shelves.stockInfo()

    def reviewCurrentNetProfit(self): #展示当前净利润[功能]
        print(f"Total Net Profit is {self.log.showTotalNetProfit()}")
        

    def replenishmentStock(self,replenishmentOrderList,shelves): #上架[功能] 假设供应商可以当天送达

        if  replenishmentOrderList == []:
            print('No replenishment record.')
        else:
            for record in replenishmentOrderList:
                shelves.shelfDict[record.itemTypeId].addItem(itemObject=record)

    def preReplenishmentStock(self,replenishmentOrderList,itemTypeId,itemNameId,itemNumber,suppliers,day):

        thisCost = suppliers.supplierDict[itemTypeId].itemDict[itemNameId].unitCost * itemNumber
        self.log.logBook[day].writeInCost(thisCost)

        replenishmentOrderList.append(Items(itemTypeId,itemNameId,itemNumber,suppliers,day))

        

            