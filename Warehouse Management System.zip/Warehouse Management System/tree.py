from curses import keyname


class UserDefinedDataStructure():
    
    def __init__(self):
        
        pass
    
    def toString(self):
        
        pass

class Root():
    def __init__(self,rootKey,rootValue):
        self.rootKey = rootKey
        self.rootValue = rootValue
        

class Tree(UserDefinedDataStructure):
    
    def __init__(self, rootKey,rootValue):
        
        super().__init__()
        
        self.key = Root(rootKey, rootValue)
        self.children = []
    
    def insert(self, newRootKey,newRootValue):
        
        newTree = Tree(newRootKey,newRootValue)
        self.children.append(newTree)
        
        return newTree
    
    def getRootVal(self):
        
        return self.key.rootValue
    
    def setRootVal(self, obj):
        
        self.key.rootValue = obj
    
    def getChildren(self):
        
        return self.children


    
    def toString(self, tab_count=0):
        
        if tab_count > 0:
            
            print('\t' * tab_count, sep='', end='')
        
        print(str(self.key))
        tab_count += 1        
        
        for child in self.children:
                                    
            child.toString(tab_count)        