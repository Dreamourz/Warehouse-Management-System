from hashlib import new
from re import I
from manager import *
from items import *
from shelf import *
from supplier import *
from tree import *
from customer import *
#===================== START INITIALIZATION ==========================
shelves = Shelves()
shelves.appendShelfList(shelfId='s01')
shelves.appendShelfList(shelfId='s02')

suppliers=Suppliers()
suppliers.addSupplier(supplierId='s01')
suppliers.addSupplier(supplierId='s02')
suppliers.supplierDict['s01'].addUnit(unitNameId='i11',unitCost=100)
suppliers.supplierDict['s01'].addUnit(unitNameId='i12',unitCost=110)
suppliers.supplierDict['s02'].addUnit(unitNameId='i21',unitCost=10)
suppliers.supplierDict['s02'].addUnit(unitNameId='i22',unitCost=20)

manager = Manager()

#===================== END INITIALIZATION ==========================

print("="*30)
day = 0
print(day)
shelves.delAllExpiredItems(day)
#shelves.saleAllItems(day)
manager.showStockInfo(shelves)
manager.log.createNewDailyTransaction(day=day)
manager.reviewCurrentNetProfit()

manager.replenishmentStock(shelves=shelves,  itemTypeId='s01', itemNameId='i11', itemNumber=20, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves, itemTypeId='s01', itemNameId='i12', itemNumber=30, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves,  itemTypeId='s02', itemNameId='i21', itemNumber=6, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves,  itemTypeId='s02', itemNameId='i22', itemNumber=8, suppliers=suppliers, day=day)

print("="*30)
day=1
print(day)
shelves.delAllExpiredItems(day)
#shelves.saleAllItems(day)
manager.showStockInfo(shelves)
manager.log.createNewDailyTransaction(day=day)
manager.reviewCurrentNetProfit()

manager.replenishmentStock(shelves=shelves,  itemTypeId='s01', itemNameId='i11', itemNumber=20, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves,  itemTypeId='s01', itemNameId='i12', itemNumber=30, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves,  itemTypeId='s02', itemNameId='i21', itemNumber=6, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves,  itemTypeId='s02', itemNameId='i22', itemNumber=8, suppliers=suppliers, day=day)

print("="*30)
day=2
print(day)
shelves.delAllExpiredItems(day)
#shelves.saleAllItems(day)
manager.showStockInfo(shelves)
manager.log.createNewDailyTransaction(day=day)
manager.reviewCurrentNetProfit()

manager.replenishmentStock(shelves=shelves,  itemTypeId='s01', itemNameId='i11', itemNumber=20, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves, itemTypeId='s01', itemNameId='i12', itemNumber=30, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves,  itemTypeId='s02', itemNameId='i21', itemNumber=6, suppliers=suppliers, day=day)
manager.replenishmentStock(shelves=shelves,  itemTypeId='s02', itemNameId='i22', itemNumber=8, suppliers=suppliers, day=day)


print("="*30)
day=3
print(day)
shelves.delAllExpiredItems(day)
#shelves.saleAllItems(day)
manager.showStockInfo(shelves)
manager.log.createNewDailyTransaction(day=day)
manager.reviewCurrentNetProfit()

customers = Customers(suppliers=suppliers,shelves=shelves)
customers.makeOrders(customerName='Rowan',suppliers=suppliers)
customers.makeOrders(customerName='Elvis',suppliers=suppliers)
customers.cancelOrders()


print("="*30)
day = 4
print(day)
manager.log.createNewDailyTransaction(day=day)
manager.reviewCurrentNetProfit()
customers.combineAllOrders(suppliers=suppliers,manager=manager,day=day)
shelves.deliverItems(orderCollectionFromCustomers=customers.orderCollection)
print(customers.customerDict)
print(customers.orderCollection)
shelves.delAllExpiredItems(day)
#shelves.saleAllItems(day)
manager.showStockInfo(shelves)





