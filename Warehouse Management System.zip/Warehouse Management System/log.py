class DailyTransaction():
    def __init__(self):
        self.cost = 0
        self.profit = 0
        #self.netProfit = self.profit - self.cost
    
    def writeInCost(self,cost):
        self.cost += cost
    
    def writeInProfit(self,profit):
        self.profit += profit

class Log():
    def __init__(self):
        self.logBook = {}
    
    def createNewDailyTransaction(self,day):
        self.logBook[day] = DailyTransaction()

    def showTotalNetProfit(self):
        if self.logBook == {}:
            return 0
        else:
            totalNetProfit = 0
            for transaction in self.logBook.values():
                totalNetProfit += transaction.profit - transaction.cost
            return totalNetProfit


