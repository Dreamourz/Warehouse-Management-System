from order import * 
#import functions as funcs

class Customer():
    def __init__(self,customerName,suppliers):
        self.customerName=customerName
        self.orderDict={}
        self.orderInfoDict = suppliers.showHierachy() #空壳

    def makeAnOrder(self,itemTypeId,itemNameId,itemNumber):
        anOrder = unitOrder(itemTypeId,itemNameId,itemNumber)
        self.orderDict[anOrder.unitOrderId] = anOrder

    def makeOrders(self,suppliers,shelves,allItemNumberDict):

        #allItemNumberDict = shelves.getAllItemNumberDict()

        active = True

        while active:

            tempTypeIdList = []
            for key in allItemNumberDict.keys():

                if shelves.shelfDict[key].linkedList.headNode.next != None:
                    tempTypeIdList.append(key)
                    print(key)

            if tempTypeIdList == []:
                return print("No items in warehouse.")

            else:

                itemTypeId = input("Input itemTypeId: ")
                while itemTypeId not in tempTypeIdList:
                    itemTypeId = input("Not Found. Pls reinput itemTypeId: ")

                for name, number in allItemNumberDict[itemTypeId].items():
                    print(f'{name}: {number} units, {suppliers.supplierDict[itemTypeId].itemDict[name].unitCost * 1.5} S$ per each')
                itemNameId = input("Input itemNameId: ")
                while itemNameId not in allItemNumberDict[itemTypeId].keys():
                    itemNameId = input("Not Found. Pls reinput itemNameId: ")

                itemNumber = int(input("itemNumber: "))
                while itemNumber> allItemNumberDict[itemTypeId][itemNameId]:
                    print('Exceeds Upper Bound')
                    itemNumber = int(input("Pls reinput itemNumber: "))
                allItemNumberDict[itemTypeId][itemNameId]-=itemNumber

                self.makeAnOrder(itemTypeId,itemNameId,itemNumber)

                active = False if input('whether continue [y/n]: ') == 'n' else True

    def cancelAnOrder(self,unitOrderId,allItemNumberDict):
        targetOrder = self.orderDict[unitOrderId]
        allItemNumberDict[targetOrder.itemTypeId][targetOrder.itemNameId] += targetOrder.itemNumber
        print(f'Customer {self.customerName} has cancelled Order {unitOrderId} successfully!')

        del self.orderDict[unitOrderId]

    def combineOrder(self,suppliers):
        billForThisCustomer = 0

        print(f'The orders made by {self.customerName} are as follows:')

        for order in self.orderDict.values():
            print(order.unitOrderId)
            billForThisCustomer += suppliers.supplierDict[order.itemTypeId].itemDict[order.itemNameId].unitCost * 1.5 * order.itemNumber
            self.orderInfoDict[order.itemTypeId][order.itemNameId] += order.itemNumber
        print(f'Total expense is {billForThisCustomer} S$')

        return billForThisCustomer




class Customers():
    def __init__(self,suppliers,shelves):

        self.customerDict={}
        self.orderCollection=suppliers.showHierachy()
        self.allItemNumberDict = shelves.getAllItemNumberDict() #获得当前产品库存
    
    def makeOrders(self,customerName,suppliers,shelves): #下单【功能】
        if customerName not in self.customerDict:
            self.customerDict[customerName] = Customer(customerName,suppliers)
        self.customerDict[customerName].makeOrders(suppliers,shelves,self.allItemNumberDict)

    def cancelOrders(self): #用户删除订单，需要输入用户的名字和订单号 【功能】
        if self.customerDict == {}:
            print('No Transaction Record.')
        else:
            print(self.customerDict.keys())
            customerName = input('Who are you: ')
            while customerName not in self.customerDict.keys():
                customerName = input('Who are you again: ')
            if self.customerDict[customerName].orderDict == {}:
                print('No Order Id here.')
                del self.customerDict[customerName]
                
            else:
                print(self.customerDict[customerName].orderDict.keys())
                unitOrderId = input('Input the OrderId: ')
                while unitOrderId not in self.customerDict[customerName].orderDict.keys():
                    unitOrderId = input('Not Found. Pls Reinput the OrderId: ')

                self.customerDict[customerName].cancelAnOrder(unitOrderId,self.allItemNumberDict)

                if self.customerDict[customerName].orderDict == {}:
                    del self.customerDict[customerName]

    def combineAllOrders(self,suppliers,manager,day): #合单【调用】
        totalProfitForToday = 0
        for customer in self.customerDict.values():
            totalProfitForToday += customer.combineOrder(suppliers)
            
            for key1, value in self.orderCollection.items():
                for key2 in value.keys():
                    self.orderCollection[key1][key2] += customer.orderInfoDict[key1][key2]

        manager.log.logBook[day].writeInProfit(totalProfitForToday)
        

    


        
    
        
        
        
        






