from udslinearlib import UserDefinedDataStructure



class BinaryTree(UserDefinedDataStructure):
    
    def __init__(self, rootObj):
        
        super().__init__()
        
        self.key = rootObj
        self.left = None
        self.right = None
    
    
    
    def insertLeft(self, newNode):
        
        if self.left == None:
            
            self.left = BinaryTree(newNode)
            
        else:
            
            bt = BinaryTree(newNode)
            bt.left = self.left
            self.left = bt
    
    
    
    def insertRight(self, newNode):
        
        if self.right == None:
            
            self.right = BinaryTree(newNode)
            
        else:
            
            bt = BinaryTree(newNode)
            bt.right = self.right
            self.right = bt
    
    
    
    def getRootVal(self):
        
        return self.key
    
    
    
    def setRootVal(self, obj):
        
        self.key= obj
    
    
    
    def getLeftChild(self):
        
        return self.left
    
    
    
    def getRightChild(self):
        
        return self.right
    
    
    
    def toString(self):
        
        strVal = str(self.key)
        strVal += ', ' + str(self.left.key if self.left != None else self.left)
        strVal += ', ' + str(self.right.key if self.right != None else self.right)
        
        return strVal



class Tree(UserDefinedDataStructure):
    
    def __init__(self, rootObj):
        
        super().__init__()
        
        self.key = rootObj
        self.children = []
    
    
    
    def insert(self, newNode):
        
        newTree = Tree(newNode)
        self.children.append(newTree)
        
        return newTree
    
    
    
    def getRootVal(self):
        
        return self.key
    
    
    
    def setRootVal(self, obj):
        
        self.key= obj
    
    
    
    def getChildren(self):
        
        return self.children
    
    
    
    def toString(self, tab_count=0):
        
        if tab_count > 0:
            
            print('\t' * tab_count, sep='', end='')
        
        print(str(self.key))
        tab_count += 1        
        
        for child in self.children:
                                    
            child.toString(tab_count)        



class Vertex(UserDefinedDataStructure):
    
    def __init__(self, key):
        
        super().__init__()
        
        self.key = key
        self.adjacentList = list([])
    
    
    
    def addNeighbour(self, neighbour, weight=0):
        
        neighbourExist = False
        
        for adjacentItem in self.adjacentList:
            
            if adjacentItem[0].key == neighbour.key:
                
                neighbourExist = True
                break
        
        if not neighbourExist:
        
            self.adjacentList.append((neighbour, weight))
    
    
    
    def toString(self):
        
        strData = str(self.key)
        
        for adjacentVertex in self.adjacentList:
            
            strData += ' -> ' + str(adjacentVertex[0].key) + ':' + str(adjacentVertex[1])
        
        return strData



class Graph():
    
    def __init__(self):
        
        self.vertices = dict({})
        self.numVertices = 0
    
    
    
    def addVertex(self, key):
        
        self.numVertices += 1
        newVertex = Vertex(key)
        self.vertices[key] = newVertex
        
        return newVertex
    
    
    
    def getVertex(self, key):
        
        if key in self.vertices.keys():
            
            return self.vertices[key]
        
        else:
            
            return None
    
    
    
    def addEdge(self, fromKey, toKey, weight=0):
        
        if not self.has_key(fromKey):
            
            self.addVertex(fromKey)
        
        if not self.has_key(toKey):
            
            self.addVertex(toKey)
        
        self.vertices[fromKey].addNeighbour(self.vertices[toKey], weight)
    
    
    
    def getVertices(self):
        
        return self.vertices.values()
    
    
    
    def has_key(self, key):
        
        if key in self.vertices.keys():
            
            return True
        
        else:
            
            return False
