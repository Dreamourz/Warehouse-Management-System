from udsnonlinearlib import Graph



def main():
    
    graph = Graph()
    
    for i in range(6):
        
        graph.addVertex('V' + str(i))
    
    graph.addEdge('V0', 'V1', 5)
    graph.addEdge('V0', 'V5', 2)
    
    graph.addEdge('V1', 'V2', 4)
    
    graph.addEdge('V2', 'V3', 9)
    
    graph.addEdge('V3', 'V4', 7)
    graph.addEdge('V3', 'V5', 3)
    
    graph.addEdge('V4', 'V0', 1)
    
    graph.addEdge('V5', 'V2', 1)
    graph.addEdge('V5', 'V4', 8)

    for vertex in graph.getVertices():
        
        print(vertex.toString())



if __name__ == '__main__':
    
    main()
