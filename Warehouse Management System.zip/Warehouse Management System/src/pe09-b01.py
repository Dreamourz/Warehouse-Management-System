from udsnonlinearlib import Tree



def main():
    
    tree = Tree('A')    
    tree.insert('B')
    tree.insert('C')
    tree.insert('D')
    
    tree.getChildren()[0].insert('E')
    tree.getChildren()[0].insert('F')
    tree.getChildren()[0].insert('G')
    
    tree.getChildren()[1].insert('H')
    tree.getChildren()[1].insert('I')
    tree.getChildren()[1].insert('J')
    
    tree.getChildren()[2].insert('K')
    tree.getChildren()[2].insert('L')
    tree.getChildren()[2].insert('M')
    
    tree.toString()



if __name__ == '__main__':
    
    main()
