from udsnonlinearlib import Graph
from udslinearlib import Queue



def breadthFirstSearch(graph, key):
    
    queue = Queue()
    queue.enqueue(key)
    
    discovered = list([])
    discovered.append(key)
    
    while not queue.empty():
        
        currentV = queue.dequeue()
        print(currentV, end=' ')
        
        for v in graph.getVertex(currentV).adjacentList:
            
            if v[0].key not in discovered:
                
                discovered.append(v[0].key)
                queue.enqueue(v[0].key)



def main():
    
    graph = Graph()
    
    for i in range(6):
        
        graph.addVertex('V' + str(i))
    
    # Weight is not important and we leave it as default of 0
    graph.addEdge('V0', 'V1')
    graph.addEdge('V0', 'V5')
    
    graph.addEdge('V1', 'V2')
    
    graph.addEdge('V2', 'V3')
    
    graph.addEdge('V3', 'V4')
    graph.addEdge('V3', 'V5')
    
    graph.addEdge('V4', 'V0')
    
    graph.addEdge('V5', 'V2')
    graph.addEdge('V5', 'V4')
    
    breadthFirstSearch(graph, 'V0')
    print()
    
    breadthFirstSearch(graph, 'V3')
    print()
    
    breadthFirstSearch(graph, 'V5')
    print()
    
    
if __name__ == '__main__':
    
    main()
