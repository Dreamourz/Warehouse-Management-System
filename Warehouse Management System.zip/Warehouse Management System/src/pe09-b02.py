from udsnonlinearlib import Tree



class InvalidPathException(Exception):
    
    pass



class FileSystem():
    
    def __init__(self):
        
        self.rootFolder = Tree('/')
    
    
    
    def listFileSystem(self):
        
        self.rootFolder.toString()
    
    
        
    def createFolderFile(self, path):
        
        if path != None:
            
            path = str(path).strip()
            
            if len(path) > 0 and path[0] == '/':
                
                pathElements = path[1:].split('/')
                self.create(self.rootFolder, pathElements)
                
            else:
                
                raise InvalidPathException('Path must start from root folder')
            
        else:
            
            raise InvalidPathException('Path not provided')   
    
    
    
    def create(self, rootFolder, pathElements):
        
        if len(pathElements) == 0:
            
            return
        
        currentPathElement = pathElements.pop(0)        
        foundChild = None
        
        for child in rootFolder.children:
            
            if child.getRootVal() == currentPathElement:
                                
                foundChild = child
                break
                        
        if foundChild == None:
            
            foundChild = rootFolder.insert(currentPathElement)
            
        
        self.create(foundChild, pathElements)



def main():
    
    fileSystem = FileSystem()
    fileSystem.createFolderFile('/folder1/subfolder1a/file1a1')
    fileSystem.createFolderFile('/folder1/subfolder1a/file1a2')
    fileSystem.createFolderFile('/folder1/subfolder1b/file1b1')
    fileSystem.createFolderFile('/folder1/subfolder1b/file1b2')
    fileSystem.createFolderFile('/folder1/subfolder1c/file1c1')
    fileSystem.createFolderFile('/folder1/subfolder1c/file1c2')
    fileSystem.createFolderFile('/folder2/subfolder2a/file2a1')
    fileSystem.createFolderFile('/folder3/subfolder3a/subfolder3a1/subfolder3a1i/file3a1ione')
    fileSystem.listFileSystem()



if __name__ == '__main__':
    
    main()
