from linklist import *
from items import *

class Shelf():
    def __init__(self,shelfId):
        self.shelfId=shelfId
        self.linkedList=LinkedList(None)

    def addItem(self,itemObject):
        self.linkedList.append(itemObject)

    def saleItem(self,day):
        currentNode = self.linkedList.headNode

        while currentNode.next != None:
            daysLeft = currentNode.next.data.expireDate - day
            if daysLeft<=3:

                currentNode.next.data.itemPrice *=  (0.5+0.1*daysLeft)

            currentNode = currentNode.next

    # def saleItem(self,day):
    #     currentNode = self.linkedList.headNode

    #     while currentNode.next != None:

    #         daysLeft = currentNode.next.data.expireDate - day
    #         if daysLeft<=3:

    #             currentNode.next.data.itemPrice *=  (0.5+0.1*daysLeft)

    #         currentNode = currentNode.next

    def getItemNumberDict(self):
        itemNumberDict={}
        currentNode = self.linkedList.headNode
        while currentNode.next !=None:
            if currentNode.next.data.itemNameId in itemNumberDict:
                itemNumberDict[currentNode.next.data.itemNameId] += currentNode.next.data.itemNumber
            else:
                itemNumberDict[currentNode.next.data.itemNameId] = currentNode.next.data.itemNumber
                # itemNumberDict['ItemPrice'] = currentNode.next.data.itemPrice

            currentNode = currentNode.next

        return itemNumberDict


    def delExpiredItem(self,manager,day): 

        currentNode = self.linkedList.headNode

        while currentNode.next != None:
                
            if currentNode.next.data.expireDate <= day:

                disposedRevenue = round(currentNode.next.data.itemPrice / 1.5 * 0.5 * currentNode.next.data.itemNumber,1)

                manager.log.logBook[day].writeInProfit(disposedRevenue)

                print(f'{currentNode.next.data.itemNumber} units of {currentNode.next.data.itemNameId} have been disposed with {disposedRevenue} S$')

                currentNode.next = currentNode.next.next #删除

                if  currentNode.next == None:
                    break
            else:

                currentNode = currentNode.next


    def delNoStockItem(self,itemNameId,itemNumber):

        currentNode = self.linkedList.headNode

        while itemNumber !=0:
            if currentNode.next.data.itemNameId == itemNameId:

                if currentNode.next.data.itemNumber > itemNumber:
                    currentNode.next.data.itemNumber -= itemNumber
                    break
                else:
                    itemNumber -= currentNode.next.data.itemNumber
                    currentNode.next = currentNode.next.next
            else:
                currentNode = currentNode.next #前进




class Shelves():

    shelfDict={}

    def appendShelfList(self,shelfId):
        self.shelfDict[shelfId]=Shelf(shelfId)

    def delAllExpiredItems(self, manager, day): #下架过期产品 【*功能】
        for shelf in self.shelfDict.values():
            shelf.delExpiredItem(manager, day)
    
    # def saleAllItems(self, day):
    #     for shelf in self.shelfDict.values():
    #         shelf.saleItem(day)

    def deliverItems(self, orderCollectionFromCustomers): #发货 【*功能】

        for key1, val1 in orderCollectionFromCustomers.items():
            for key2, val2 in val1.items():
                self.shelfDict[key1].delNoStockItem(key2,val2)
                if val2:
                    print(f'{val2} units of {key2} have been removed from shelf {key1} and delivered successfully!')

    def stockInfo(self): #展示仓库现有所有物品的信息
        for key, shelf in self.shelfDict.items():

            print(f'Shelf {key}: ')
            currentNode = shelf.linkedList.headNode

            while currentNode.next != None:
                item = currentNode.next.data
                print(f'ItemId: {item.itemId} \
                ItemTypeId: {item.itemTypeId} \
                ItemNameId: {item.itemNameId} \
                ItemNumber: {item.itemNumber} \
                ProduceDate: {item.produceDate} \
                ExpireDate: {item.expireDate} \
                ItemPrice: {item.itemPrice}')
                currentNode = currentNode.next

    def getAllItemNumberDict(self):
        allItemNumberDict={}
        for key, value in self.shelfDict.items():
            allItemNumberDict[key] = value.getItemNumberDict()
        return allItemNumberDict


        