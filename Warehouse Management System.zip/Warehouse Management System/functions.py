import random
# def locateChild(tree,val1,key2):
#     currentNode = tree
#     for node1 in currentNode.children:
#         if node1.key.rootValue == val1:
#             currentNode = node1
#             break
#     for node2 in currentNode.children:
#         if node2.key.rootKey == key2:
#             currentNode = node2
#             break
#     return currentNode

def generateId(choice):
    randomNumber = int(round(random.random(),6) * 10**6)
    if choice == 'items':
        return '#I'+str(randomNumber)
    elif choice == 'order':
        return '#O'+str(randomNumber)

            
