from udslib import Deque



def main():
    
    word = input('Enter an English word = ').strip().lower()
    
    is_palindrome = True
    deque = Deque()
    
    for char in word:
        
        deque.addRear(char)
    
    while deque.size() > 1:
        
        if deque.removeFront() != deque.removeRear():
            
            is_palindrome = False
            break
    
    if is_palindrome:
        
        print('{} is a palindrome'.format(word))
    
    else:
        
        print('{} is NOT a palindrome'.format(word))



if __name__ == '__main__':
    
    main()
