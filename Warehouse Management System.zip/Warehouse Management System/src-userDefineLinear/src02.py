from udslib import Stack



def main():
    
    exp = input('Enter a Python expression with brackets = ')        
    
    is_balanced = True
    stack = Stack()
    
    for sym in exp:
        
        if sym in ['(','[','{']:
            
            stack.push(sym)
        
        elif sym in [')',']','}']:
            
            top_sym = stack.pop()
            
            if not ((sym == ')' and top_sym == '(') or (sym == ']' and top_sym == '[') or (sym == '}' and top_sym == '{')):
            
                is_balanced = False
                break
    
    if not stack.empty():
        
        is_balanced = False
    
    if is_balanced:
        
        print('{} is balanced'.format(exp))
    
    else:
        
        print('{} is NOT balanced'.format(exp))



if __name__ == '__main__':
    
    main()
