from udslib import Stack



def main():
    
    stack = Stack()
    print(stack.toString())
    
    for i in range(1, 6, 1):
        
        stack.push(i)
        print(stack.toString())
    
    while not stack.empty():
        
        print(stack.pop())
        print(stack.toString())



if __name__ == '__main__':
    
    main()
