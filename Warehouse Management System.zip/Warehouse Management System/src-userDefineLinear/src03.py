from udslib import Queue



def main():
    
    queue = Queue()
    print(queue.toString())
    
    for i in range(1, 6, 1):
        
        queue.enqueue(i)
        print(queue.toString())
    
    while not queue.empty():
        
        print(queue.dequeue())
        print(queue.toString())



if __name__ == '__main__':
    
    main()
