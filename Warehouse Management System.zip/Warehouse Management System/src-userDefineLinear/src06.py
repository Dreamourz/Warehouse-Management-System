from udslib import Node



def main():
    
    headNode = None
    currentNode = None    
    
    for i in range(1, 6, 1):
        
        if headNode == None:
            
            currentNode = headNode = Node(i)
        
        else:
            
            currentNode.next = Node(i)
            currentNode = currentNode.next
    
    currentNode = headNode
    
    while currentNode != None:
        
        print(currentNode.toString())
        currentNode = currentNode.next



if __name__ == '__main__':
    
    main()
