from udslib import LinkedList



def main():
    
    linkedList = None
    
    for i in range(1, 6, 1):
        
        if linkedList == None:
            
            linkedList = LinkedList(i)
        
        else:
            
            linkedList.append(i)
    
    print(linkedList.toString())
    
    linkedList.add(1, 'a')    
    print(linkedList.toString())
    
    linkedList.add(3, 'b')
    print(linkedList.toString())
    
    linkedList.add(5, 'c')
    print(linkedList.toString())
    
    linkedList.removeAt(1)
    print(linkedList.toString())
    
    linkedList.removeAt(2)
    print(linkedList.toString())
    
    linkedList.removeAt(3)
    print(linkedList.toString())
    
    linkedList.remove()
    print(linkedList.toString())
    
    linkedList.remove()
    print(linkedList.toString())
    
    linkedList.remove()
    print(linkedList.toString())
    
    linkedList.remove()
    print(linkedList.toString())



if __name__ == '__main__':
    
    main()
