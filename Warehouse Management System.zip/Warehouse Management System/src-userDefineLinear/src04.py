from udslib import Deque



def main():
    
    deque = Deque()
    print(deque.toString())
    
    deque.addRear('A')
    print(deque.toString())
    
    deque.addFront(1)
    print(deque.toString())
    
    deque.addRear('B')
    print(deque.toString())
    
    deque.addFront(2)
    print(deque.toString())
    
    deque.addRear('C')
    print(deque.toString())
    
    rear = True
    
    while not deque.empty():
        
        if rear:
            
            print(deque.removeRear())
        
        else:
            
            print(deque.removeFront())
            
        rear = not rear
            
        print(deque.toString())



if __name__ == '__main__':
    
    main()
