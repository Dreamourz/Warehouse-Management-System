import functions as func
class unitOrder():
    def __init__(self,itemTypeId,itemNameId,itemNumber):
        self.unitOrderId = func.generateId(choice='order')
        self.itemTypeId = itemTypeId
        self.itemNameId = itemNameId
        self.itemNumber = itemNumber

