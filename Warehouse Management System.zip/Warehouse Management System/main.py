from manager import *
from items import *
from shelf import *
from supplier import *
from tree import *
from customer import *

if __name__ == "__main__":

#===================== START INITIALIZATION ==========================
    shelves = Shelves()
    shelves.appendShelfList(shelfId='s01')
    shelves.appendShelfList(shelfId='s02')
    shelves.appendShelfList(shelfId='s03')
    shelves.appendShelfList(shelfId='s04')

    suppliers=Suppliers()
    suppliers.addSupplier(supplierId='s01')
    suppliers.addSupplier(supplierId='s02')
    suppliers.addSupplier(supplierId='s03')
    suppliers.addSupplier(supplierId='s04')
    suppliers.supplierDict['s01'].addUnit(unitNameId='i11',unitCost=100)
    suppliers.supplierDict['s01'].addUnit(unitNameId='i12',unitCost=110)
    suppliers.supplierDict['s02'].addUnit(unitNameId='i21',unitCost=10)
    suppliers.supplierDict['s02'].addUnit(unitNameId='i22',unitCost=20)
    suppliers.supplierDict['s03'].addUnit(unitNameId='i31',unitCost=210)
    suppliers.supplierDict['s03'].addUnit(unitNameId='i32',unitCost=230)
    suppliers.supplierDict['s04'].addUnit(unitNameId='i41',unitCost=56)
    suppliers.supplierDict['s04'].addUnit(unitNameId='i42',unitCost=78)

    manager = Manager()

    day = 0

#===================== END INITIALIZATION ==========================

    while True:##迭代日期

#===================== Start AUTO==========================
        print(f'Day {day}')
        manager.log.createNewDailyTransaction(day=day)
        shelves.delAllExpiredItems(manager=manager, day=day) #desposal 每天早上进行临期盘点，进行降价、销毁

        customers = Customers(suppliers=suppliers,shelves=shelves)

        replenishmentOrderList=[]
#===================== END AUTO ==========================
        
        choice = input("Ready to continue [y/n]: ")
        if choice == 'n':
            break

        while True:##迭代当天的操作
            role=input("Choose your role:\n1-customer\n2-warehouse manager :")
            while role not in ['1','2']:
                    role=input("Choose your role:\n1-customer\n2-warehouse manager :")

            print("*"*20)

            if role == '1':##身份：顾客
                action=input("Choose your action:\n 1-make order\n 2- cancel order:")
                while action not in ['1','2']:
                    action=input("Choose your action:\n 1-make order\n 2- cancel order:")

                if action == '1':##make order 下订单

                    customerName = input("What's your name?: ")
                    customers.makeOrders(customerName=customerName,suppliers=suppliers,shelves=shelves)
                   
                else:#cancel order 取消订单

                    customers.cancelOrders()
                
            elif role == '2':##身份：仓库管理者

                action=input("Choose your action:\n 1-ReplenishmentStock \n 2-ShowStockInfo \n 3-ReviewCurrentNetProfit\n  4-OffWork\n:")
                while action not in ['1','2','3','4']:

                    action=input("Choose your action:\n 1-ReplenishmentStock \n 2-ShowStockInfo \n 3-ReviewCurrentNetProfit\n 4-OffWork\n:")

                if action=='1':##item list management(add item/delete item)
                    
                    print(shelves.shelfDict.keys())
                    itemTypeId = input("Input itemTypeId: ")
                    while itemTypeId not in suppliers.supplierDict.keys():
                        itemTypeId = input("Not Found. Pls reinput itemTypeId: ")
                    

                    print(suppliers.supplierDict[itemTypeId].itemDict.keys())
                    itemNameId = input("Input itemNameId: ")
                    while itemNameId not in suppliers.supplierDict[itemTypeId].itemDict.keys():
                        itemNameId = input("Not Found. Pls reinput itemNameId: ")

                    itemNumber = int(input("Input itemNumber: "))

                    manager.preReplenishmentStock(replenishmentOrderList, itemTypeId, itemNameId, itemNumber, suppliers, day)
                    
                elif action=='2':

                    manager.showStockInfo(shelves) 

                   
                elif action =='3':

                    manager.reviewCurrentNetProfit()
                
                elif action =='4':

                   break

        #===================== Start AUTO==========================
        
        customers.combineAllOrders(suppliers=suppliers,manager=manager,day=day)

        day=day+1

        shelves.deliverItems(orderCollectionFromCustomers=customers.orderCollection)

        manager.replenishmentStock(replenishmentOrderList=replenishmentOrderList, shelves=shelves)

        #===================== End AUTO==========================
                    



            

        

            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            

