import functions as func
class Items():
    def __init__(self,itemTypeId,itemNameId,itemNumber,suppliers,day):
        self.itemId = func.generateId('items')
        self.itemTypeId = itemTypeId
        self.itemNameId = itemNameId
        self.itemNumber = itemNumber
        self.produceDate = day
        self.expireDate = day+3
        self.itemPrice = round(suppliers.supplierDict[itemTypeId].itemDict[itemNameId].unitCost * 1.5 ,1)