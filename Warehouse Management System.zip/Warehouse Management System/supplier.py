class Unit():
    def __init__(self,unitNameId,unitTypeId,unitCost):
        self.unitNameId = unitNameId
        self.unitTypeId = unitTypeId
        self.unitCost = unitCost

class Supplier():
    def __init__(self,supplierId):
        self.supplierId=supplierId
        self.itemDict={}
    
    def addUnit(self,unitNameId,unitCost):
        self.itemDict[unitNameId]=Unit(unitNameId,self.supplierId,unitCost)

class Suppliers():

    supplierDict={}

    def addSupplier(self,supplierId):
        self.supplierDict[supplierId]=Supplier(supplierId) # 增加供应商【初始化】

    def showTypeTable(self): #展示现有的供应商【初始化】
        for key in self.supplierDict.keys():
            print(f'{key}')

    def showItemTable(self,itemTypeId): #展示该供应商现有产品 【初始化】
        for value in self.supplierDict[itemTypeId].itemDict.values():
            print(f'typeId: {itemTypeId}, nameId: {value.unitNameId}, cost: {value.unitCost}')
    
    def showHierachy(self): #展示 类型 - 产品名 骨架 【调用】
        dictHierachy = {}
        for key, value1 in self.supplierDict.items():
            tempDict = {}
            for value2 in value1.itemDict.values():
                tempDict[value2.unitNameId] = 0
            dictHierachy[key] = tempDict
        return dictHierachy



