# -*- coding: utf-8 -*-
"""
Created on Tue Oct 18 11:48:25 2022

@author: Dell
"""
# 仓库内某类产品有哪些，如A类产品有列表中a b c三种
item_dict = {}

# 合并后的订单不同类产品有哪些，结构同上
orderItem_dict = {}


# 货架信息类
class ShelvesInfo():
    
    # 货架信息表结构：不同类别，先假设每个货架只能放一种产品，字典套字典形式
    # X类产品1号货架储存（产品名字，数量，生产日期, 入库日期，保质期ddl，成本价，卖出价格,过期状态）
    # 按种类分的区域
    shlDict = {'X':{'1':{'Item': 'A', 'ItemNumber': 10, 'ProductDate': 0, 'StoreDate': 1, 'ExpireDate': 18, 'ItemPrice': 20, 'SalePrice': 30, 'Status': True}, 
    '2':{}}, 'Y':{'3':{}, '4':{}}}
    
    def __init__(self, shelfType, shlDict):
        
        self.shelfType = shelfType
        self.shlDict = shlDict
        
    def getDict(self):
        
        # 按种类调取货架信息
        return self.shlDict[self.shelfType]
    
    def getNum(self, item_dict):
        
        #获得该种类的货架上所有货品数量dict
        
        temp = self.shlDict[self.shelfType]
        
        #获得该种类的货物名称信息
        name_list = item_dict[self.shelfType]
        num_dict = {}
        
        #初始化货品数量字典表，初始数量为0
        for name in name_list:
            num_dict[name] = 0
        
        #遍历货架，同类货品储存数量相加
        for i in temp.keys():
            itemName = i['Item']
            num_dict[itemName] += i['ItemNumber']
        
        return num_dict                   
    
    def isExpired(self, dayTime):
        
        #输入当前日期，判断是否过期，过期标记销毁,dayTime用while循环中的局部变量i表示
        temp = self.shlDict[self.shelfType]
        
        cost = 0
        
        for i in temp.keys():
            
            if temp[i] != {}:
                ed = temp[i]['ExpireDate']
            
                if dayTime < ed:
                    #剩余天数=过期日期-目前时间
                    ld = ed - dayTime
                    
                    if ld <= 3:
                        #当剩余保质期小于三天，令售价=成本价
                        temp[i]['SalePrice'] = temp[i]['ItemPrice']
                        print(f'{i}货架临期商品已降价')
                    
                    else:
                        print(f'{i}货架没有临期商品')
            
                else:                    
                    cost += temp[i]['ItemPrice']*temp[i]['ItemNumber']
                    #将状态标记，统一销毁
                    temp[i]['Status'] = True
                    print('过期商品已标记')
                
            else:
                continue
        print(f'第{dayTime}天过期预计损失金额{cost}')
        
    def storeGood(self,  **inp):
        
        #上架功能
        dic = inp
        temp = self.shlDict[self.shelfType]
        cnt = 0
        for i in temp.keys():
            if temp[i] == {}:
                temp[i] = dic
                print(f'货物成功在{i}货架入库')
                cnt += 1
                break
            else:
                continue
            
        #用变量表示货物是否完成上架操作
        if cnt == 0:
            print('上架失败，请检查货架状态')
        else:
            print('上架完成')
            
        
        
    def isDestructuon(self, shelfName):
        
        #销毁功能
        cost = 0
        temp = self.shlDict[self.shelfType]
        
        for i in temp.keys():
            if temp[i]['Status'] == True:
                cost += temp[i]['ItemPrice']*temp[i]['ItemNumber']
                
                #货架初始化处理
                temp[i] = {}
            else:
                continue
            
        print(f'过期货物已销毁，销毁损失{cost}')
    
        
    def getLocation(self, orderItem_dict):
        
        #获得取货位置dict
        
        temp = self.shlDict[self.shelfType]
        
        #获得该种类的被取货物名称信息
        name_list = orderItem_dict[self.shelfType]
        location_dict = {}
        
        #初始化货物未知字典表，初始位置为空字符
        for name in name_list:
            location_dict[name] = ''
        
        #遍历货架，获得该商品位置
        for location in temp.keys():
            itemName = location['Item']
            location_dict[itemName] = location
        
        return location_dict
    
    
        
        
        
        
  
      
## classShlInfo 使用方法

# 实例化货物X类的货架


a = input("请输入你想查询的种类：")
XInfo = ShelvesInfo(a)
print(XInfo.getDict())


# 调用ShelfInfo的getNum方法

b = input("请输入你想查询的货架号：")
d = input("请输入当前日期：")
d = int(d)

XInfo.isExpired(d)

'''

x = input("请输入你想上架的货物种类：")
y = input("请输入你想上架的货架号：")
inp = input("请输入你想上架的货品产品名字，数量，生产日期, 入库日期，保质期ddl，成本价，卖出价格：")
Xinfo = ShelvesInfo(x)
Xinfo.storeGood(y, inp)



'''